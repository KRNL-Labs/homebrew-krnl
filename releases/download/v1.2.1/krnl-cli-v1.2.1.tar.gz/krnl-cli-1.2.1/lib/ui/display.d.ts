/**
 * Creates a styled section header
 */
export declare function displaySectionHeader(title: string): void;
/**
 * Creates a styled step header
 */
export declare function displayStepHeader(step: string, title: string): void;
/**
 * Creates a warning box
 */
export declare function displayWarningBox(title: string, ...lines: string[]): void;
/**
 * Creates an info box
 */
export declare function displayInfoBox(title: string, items: Record<string, string>): void;
/**
 * Creates a summary box
 */
export declare function displaySummaryBox(title: string, items: Record<string, string>): void;
