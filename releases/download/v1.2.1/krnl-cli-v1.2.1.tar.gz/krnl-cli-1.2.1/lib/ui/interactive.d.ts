/**
 * Creates an enhanced interactive prompt with styled text
 */
export declare function createPrompt(): {
    question: (text: string, defaultValue?: string) => Promise<string>;
    confirm: (text: string, defaultValue?: boolean) => Promise<boolean>;
    select: <T extends string>(text: string, options: T[], defaultOption?: T) => Promise<T>;
    multiSelect: <T extends string>(text: string, options: T[]) => Promise<T[]>;
    close: () => void;
};
/**
 * Shows a progress bar with percentage and label
 * @param progress Current progress value (0-1)
 * @param label Label to display next to the progress bar
 * @param width Width of the progress bar in characters
 * @param completed Whether the task has been completed
 */
export declare function showProgressBar(progress: number, label?: string, width?: number, completed?: boolean): void;
/**
 * Creates an interactive menu with keyboard navigation
 * @param title Menu title
 * @param options Array of menu options
 * @returns Promise that resolves to the selected option
 */
export declare function createInteractiveMenu<T extends string>(title: string, options: T[]): Promise<T>;
