export interface Spinner {
    stop: () => void;
    succeed: (text?: string) => void;
    fail: (text?: string) => void;
    warn: (text?: string) => void;
    info: (text?: string) => void;
}
/**
 * Creates and starts a CLI spinner using ora
 * @param message Message to display next to the spinner
 * @returns Spinner object with various control methods
 */
export declare function startSpinner(message: string): Spinner;
