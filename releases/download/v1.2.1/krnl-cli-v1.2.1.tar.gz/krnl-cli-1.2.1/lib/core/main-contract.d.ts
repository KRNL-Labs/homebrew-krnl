/**
 * Deploy the main contract to Sepolia testnet
 * @param contractName Name of the contract to deploy (default: Sample)
 * @returns Address of the deployed contract and the TA public key address
 */
export declare function deployMainContract(contractName?: string): Promise<{
    addressMain: string;
    TAPublicKeyAddress: string;
}>;
/**
 * Verify main contract on Etherscan
 * @param address Address of the contract to verify
 * @param TAPublicKeyAddress Token Authority public key address used in constructor
 * @returns True if verification was successful or already verified
 */
export declare function verifyMainContract(address: string, TAPublicKeyAddress: string): Promise<boolean>;
