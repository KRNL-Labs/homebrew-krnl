/**
 * Deploy Token Authority contract to Oasis Sapphire testnet
 * @param projectDir Path to the project directory
 * @param contractName Name of the contract to search for in compiled output (default: TokenAuthority)
 * @returns Address of the deployed contract and its public key address
 */
export declare function deployTokenAuthority(projectDir?: string, contractName?: string): Promise<{
    addressTokenAuthority: string;
    TAPublicKeyAddress: string;
}>;
/**
 * Verify Token Authority contract on Sourcify
 * @param address Address of the contract to verify
 * @param ownerAddress Address of the contract owner
 * @returns True if verification was successful or already verified
 */
export declare function verifyTokenAuthority(address: string, ownerAddress: string, projectDir?: string): Promise<boolean>;
