/**
 * Runs Hardhat programmatically
 */
export declare function runHardhatTask(taskName: string, params: Record<string, any> | undefined, hardhatDir: string): Promise<any>;
/**
 * Creates a default Hardhat config file if not exists
 */
export declare function createDefaultHardhatConfig(projectDir: string): void;
