/**
 * Deploy Token Authority contract to Oasis Sapphire testnet
 * @returns Address of the deployed contract and its public key address
 */
export declare function deployTokenAuthority(): Promise<{
    addressTokenAuthority: string;
    TAPublicKeyAddress: string;
}>;
/**
 * Verify Token Authority contract on Sourcify
 * @param address Address of the contract to verify
 * @param ownerAddress Address of the contract owner
 * @returns True if verification was successful or already verified
 */
export declare function verifyTokenAuthority(address: string, ownerAddress: string): Promise<boolean>;
