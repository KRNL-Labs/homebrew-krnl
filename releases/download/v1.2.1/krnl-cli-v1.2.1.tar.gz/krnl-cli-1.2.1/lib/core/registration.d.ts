/**
 * Register the deployed contracts with the platform
 */
export declare function registerContracts(scAddress?: string, taAddress?: string, kernelIdsInput?: number[]): Promise<{
    contractId: number;
    dappId: number;
    entryId: string;
    accessToken: string;
}>;
