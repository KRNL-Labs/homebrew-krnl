import { ethers } from 'ethers';
/**
 * Compile smart contracts using Forge
 * @param forgeDir Path to the Forge directory
 * @param silent If true, hide compilation messages
 */
export declare function compileContracts(forgeDir: string, silent?: boolean): Promise<void>;
/**
 * Find the compiled contract file based on contract name
 * @param forgeDir Path to the Forge directory
 * @param contractName Name of the contract to find
 * @returns Path to the compiled contract file or empty string if not found
 */
export declare function findCompiledContract(forgeDir: string, contractName: string): string;
/**
 * Get contract factory for a compiled contract
 * @param forgeDir Path to the Forge directory
 * @param contractName Name of the contract
 * @param wallet Wallet to use for deployment
 */
export declare function getContractFactory(forgeDir: string, contractName: string, wallet: ethers.Wallet): ethers.ContractFactory;
/**
 * Deploy a contract using Forge
 * @param forgeDir Path to the Forge directory
 * @param contractName Name of the contract to deploy
 * @param wallet Wallet to use for deployment
 * @param constructorArgs Constructor arguments for the contract
 * @returns Address of the deployed contract
 */
export declare function deployContract(forgeDir: string, contractName: string, wallet: ethers.Wallet, constructorArgs?: any[]): Promise<string>;
/**
 * Run forge compile command directly
 * @param forgeDir Path to the Forge directory
 * @param options Additional options to pass to forge compile
 * @returns Output of the compile command
 */
export declare function compileCommand(forgeDir: string, options?: string): string;
/**
 * Verify a contract using Forge
 * @param forgeDir Path to the Forge directory
 * @param address Address of the contract to verify
 * @param network Network where the contract is deployed (e.g., 'sepolia', 'sapphire-testnet')
 * @param constructorArgs Constructor arguments used for deployment
 * @returns True if verification was successful
 */
export declare function verifyContract(forgeDir: string, address: string, network: string, constructorArgs?: any[]): Promise<boolean>;
