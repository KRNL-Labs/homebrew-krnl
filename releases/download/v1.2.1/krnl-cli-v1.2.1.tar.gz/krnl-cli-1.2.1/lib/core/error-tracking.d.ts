/**
 * Capture an exception and send it to PostHog
 * @param error Error to capture
 * @param context Additional context to include
 */
export declare function captureException(error: Error, context?: Record<string, any>): void;
/**
 * Capture a message and send it to PostHog
 * @param message Message to capture
 * @param level Severity level (for API compatibility)
 * @param context Additional context to include
 */
export declare function captureMessage(message: string, level?: string, context?: Record<string, any>): void;
/**
 * Track a CLI command execution
 * @param command Command name
 * @param args Command arguments
 */
export declare function trackCommand(command: string, args?: Record<string, any>): void;
/**
 * Flush events and gracefully shut down
 */
export declare function flushEvents(): Promise<boolean>;
