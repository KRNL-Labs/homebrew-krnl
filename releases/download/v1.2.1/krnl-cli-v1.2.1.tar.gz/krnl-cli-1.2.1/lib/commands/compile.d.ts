import { Command } from 'commander';
/**
 * Register the compile command with the CLI
 */
export declare function compileCmd(program: Command): void;
