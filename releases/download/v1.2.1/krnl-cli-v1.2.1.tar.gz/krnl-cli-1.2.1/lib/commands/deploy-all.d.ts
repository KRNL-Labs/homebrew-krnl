import { Command } from 'commander';
export declare function deployAllCommand(program: Command): void;
