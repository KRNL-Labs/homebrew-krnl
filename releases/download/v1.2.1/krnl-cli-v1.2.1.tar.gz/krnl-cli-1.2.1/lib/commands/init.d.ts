import { Command } from 'commander';
/**
 * Registers the init command with the CLI
 */
export declare function initCommand(program: Command): void;
