import { Command } from 'commander';
export declare function registerCommand(program: Command): void;
