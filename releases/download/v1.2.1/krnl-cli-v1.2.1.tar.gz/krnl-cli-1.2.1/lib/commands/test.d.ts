import { Command } from 'commander';
/**
 * Register the test command with the CLI
 */
export declare function testCmd(program: Command): void;
