import { Command } from 'commander';
export declare function deployTACommand(program: Command): void;
