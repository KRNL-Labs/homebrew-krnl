# KRNL Hardhat Template

Follow these steps if you want to use Hardhat as a smart contract development tool.

## 1. Install dependencies

```shell
npm install
```

## 2. Fill .env

## 3. Deploy all contracts, verify, and register through KRNL Platform

```shell
npm run dvr
```


