# KRNL CLI

A command-line interface for the KRNL platform that simplifies deploying and registering smart contracts.

## Features

- Simple, guided setup process
- Project initialization with contract templates
- Automated deployment of Token Authority and Main contracts
- Contract verification on Sourcify and Etherscan
- Platform registration with the KRNL registry
- Self-contained with bundled Forge - no external dependencies required
- Customizable contract names for flexible deployment
- Robust contract finding mechanism across different Forge configurations

## Installation

### Global Installation

```bash
npm install -g krnl-cli
```

### Local Development

```bash
# Clone the repository
git clone https://github.com/your-org/krnl-cli.git
cd krnl-cli

# Install dependencies
npm install

# Build the CLI
npm run build

# Create a global link for development
npm link
```

## Usage

### Initialize a New Project

```bash
# Create a new directory for your project
mkdir my-krnl-project
cd my-krnl-project

# Initialize with KRNL CLI
krnl init
```

### Configure Environment

```bash
# Set up environment variables and wallet
krnl setup
```

### Deploy Contracts

```bash
# Deploy Token Authority contract
krnl deploy-ta
# With custom contract name
krnl deploy-ta --contract-name MyTokenAuthority

# Deploy Main contract
krnl deploy-main
# With custom contract name
krnl deploy-main --contract-name MyMainContract

# Register contracts with the KRNL platform
krnl register

# Or run the entire process at once
krnl deploy-all
# With custom contract names
krnl deploy-all --ta-contract MyTokenAuthority --main-contract MyMainContract
```

### Compile Contracts

```bash
# Compile contracts with Forge
krnl compile
# With additional options
krnl compile --options "--via-ir"
```

## Project Structure

When you initialize a new project with `krnl init`, it creates the following structure:

```
my-krnl-project/
├── src/                    # Standard Forge source directory
│   ├── TokenAuthority.sol
│   └── Sample.sol
├── foundry.toml            # Forge configuration
├── package.json
├── .gitignore
├── .env.example
└── README.md
```

## Configuration

The CLI uses a `.env` file for configuration. Run `krnl setup` to create and configure this file. Key configuration options include:

- `PRIVATE_KEY_OASIS`: Private key for Oasis Sapphire testnet
- `PRIVATE_KEY_SEPOLIA`: Private key for Sepolia testnet
- `KERNEL_ID`: Kernel IDs to use for registration
- `ETHERSCAN_API_KEY`: API key for contract verification

## Commands

- `krnl init [directory]` - Initialize a new KRNL project
- `krnl setup` - Configure environment variables and create wallets
- `krnl deploy-ta [options]` - Deploy Token Authority contract
  - `-c, --contract-name <name>` - Specify the contract name (default: TokenAuthority)
- `krnl deploy-main [options]` - Deploy Main contract
  - `-c, --contract-name <name>` - Specify the contract name (default: Sample)
- `krnl register` - Register contracts with the KRNL platform
- `krnl deploy-all [options]` - Run the entire deployment process
  - `-ta, --ta-contract <name>` - Specify the Token Authority contract name
  - `-mc, --main-contract <name>` - Specify the Main contract name
- `krnl compile [options]` - Compile contracts with Forge
  - `-o, --options <options>` - Additional options to pass to forge compile
  - `-d, --dir <directory>` - Specify a directory other than the current one
  - `-v, --verbose` - Show detailed output

## Development

### Project Structure

```
krnl-cli/
├── bin/
│   └── cli.js              # CLI entry point
├── src/
│   ├── commands/           # CLI command implementations
│   ├── core/               # Core blockchain logic
│   └── ui/                 # UI utilities
├── templates/
│   └── project/            # Project templates
│       └── contracts/      # Smart contract templates
├── package.json
└── tsconfig.json
```

### Building

```bash
npm run build
```

### Testing

```bash
npm test
```

## License

[MIT](LICENSE)