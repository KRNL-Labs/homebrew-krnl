import { ethers } from 'ethers';
export interface DeployedContracts {
    tokenAuthorityAddress: string;
    tokenAuthorityPublicKey: string;
    registeredSmartContractAddress: string;
}
/**
 * Read deployed contracts JSON file
 */
export declare function readDeployedContracts(filePath?: string): DeployedContracts;
/**
 * Write deployed contracts JSON file
 */
export declare function writeDeployedContracts(data: DeployedContracts, filePath?: string): void;
/**
 * Get provider for Oasis Sapphire testnet
 */
export declare function getOasisProvider(): ethers.JsonRpcProvider;
/**
 * Get provider for Sepolia testnet
 */
export declare function getSepoliaProvider(): ethers.JsonRpcProvider;
/**
 * Get wallet for Oasis Sapphire testnet
 */
export declare function getOasisWallet(): ethers.Wallet;
/**
 * Get wallet for Sepolia testnet
 */
export declare function getSepoliaWallet(): ethers.Wallet;
/**
 * Get kernel IDs from environment
 */
export declare function getKernelIds(): number[];
/**
 * Wait for a specified time
 */
export declare function wait(ms: number): Promise<void>;
/**
 * Check if a wallet has sufficient balance
 */
export declare function checkBalance(wallet: ethers.Wallet, minBalance?: string): Promise<boolean>;
/**
 * Get the project root directory
 */
export declare function getProjectRoot(): string;
/**
 * Get the forge directory for smart contract operations
 * This replaces the previous getHardhatDir function
 */
export declare function getForgeDir(): string;
/**
 * Legacy function for backward compatibility
 * @deprecated Use getForgeDir instead
 */
export declare function getHardhatDir(): string;
/**
 * Get the path to Foundry executables
 */
export declare function getFoundryPath(): string | undefined;
/**
 * Get the full path to a Foundry executable (forge, cast, etc.)
 */
export declare function getFoundryExecutable(name?: string): string;
