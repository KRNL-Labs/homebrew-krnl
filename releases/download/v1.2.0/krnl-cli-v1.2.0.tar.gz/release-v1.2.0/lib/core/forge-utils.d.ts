/**
 * Runs Forge command
 */
export declare function runForgeCommand(command: string, params: string[] | undefined, forgeDir: string): Promise<string>;
/**
 * Creates a default Forge config file if not exists
 */
export declare function createDefaultForgeConfig(projectDir: string): void;
