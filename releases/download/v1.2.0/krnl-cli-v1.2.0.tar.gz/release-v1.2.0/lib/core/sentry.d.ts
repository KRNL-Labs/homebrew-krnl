import * as Sentry from '@sentry/node';
/**
 * Initialize Sentry for error tracking
 * @param dsn Sentry DSN (can be overridden with SENTRY_DSN env var)
 * @param environment Environment name (defaults to 'production', can be overridden with SENTRY_ENVIRONMENT env var)
 */
export declare function initSentry(dsn?: string, environment?: string): void;
/**
 * Capture an exception and send it to Sentry
 * @param error Error to capture
 * @param context Additional context to include
 */
export declare function captureException(error: Error, context?: Record<string, any>): void;
/**
 * Capture a message and send it to Sentry
 * @param message Message to capture
 * @param level Severity level
 * @param context Additional context to include
 */
export declare function captureMessage(message: string, level?: Sentry.SeverityLevel, context?: Record<string, any>): void;
/**
 * Track a CLI command execution
 * @param command Command name
 * @param args Command arguments (filtered to remove sensitive data)
 */
export declare function trackCommand(command: string, args?: Record<string, any>): void;
/**
 * Flush Sentry events and gracefully shut down
 */
export declare function flushEvents(): Promise<boolean>;
