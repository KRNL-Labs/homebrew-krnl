import { ethers } from 'ethers';
/**
 * Compile smart contracts using Hardhat
 * @param hardhatDir Path to the Hardhat directory
 */
export declare function compileContracts(hardhatDir: string): Promise<void>;
/**
 * Get contract factory for a compiled contract
 * @param hardhatDir Path to the Hardhat directory
 * @param contractName Name of the contract
 * @param wallet Wallet to use for deployment
 */
export declare function getContractFactory(hardhatDir: string, contractName: string, wallet: ethers.Wallet): ethers.ContractFactory;
/**
 * Deploy a contract using Hardhat
 * @param hardhatDir Path to the Hardhat directory
 * @param contractName Name of the contract to deploy
 * @param wallet Wallet to use for deployment
 * @param constructorArgs Constructor arguments for the contract
 * @returns Address of the deployed contract
 */
export declare function deployContract(hardhatDir: string, contractName: string, wallet: ethers.Wallet, constructorArgs?: any[]): Promise<string>;
/**
 * Verify a contract using Hardhat
 * @param hardhatDir Path to the Hardhat directory
 * @param address Address of the contract to verify
 * @param network Network where the contract is deployed (e.g., 'sepolia', 'sapphire-testnet')
 * @param constructorArgs Constructor arguments used for deployment
 * @returns True if verification was successful
 */
export declare function verifyContract(hardhatDir: string, address: string, network: string, constructorArgs?: any[]): Promise<boolean>;
