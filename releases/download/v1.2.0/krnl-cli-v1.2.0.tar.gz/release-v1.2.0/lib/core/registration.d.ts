/**
 * Register the deployed contracts with the platform
 */
export declare function registerContracts(): Promise<{
    contractId: number;
    dappId: number;
    entryId: string;
    accessToken: string;
}>;
