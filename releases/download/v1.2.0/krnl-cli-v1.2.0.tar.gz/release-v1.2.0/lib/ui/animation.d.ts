/**
 * Creates an animated loading bar that can be controlled via an interval
 * @param message Message to display alongside the loading bar
 * @param options Configuration options for the animation
 * @returns Object with control methods and the interval ID
 */
export declare function createLoadingBar(message: string, options?: {
    width?: number;
    speed?: number;
    color?: string;
}): {
    start: () => NodeJS.Timeout;
    stop: (success?: boolean, finalMessage?: string) => void;
};
/**
 * Creates an animated spinner with custom frames
 * @param message Message to display alongside the spinner
 * @param options Configuration options for the animation
 * @returns Object with control methods and the interval ID
 */
export declare function createSpinner(message: string, options?: {
    frames?: string[];
    speed?: number;
    color?: string;
}): {
    start: () => NodeJS.Timeout;
    stop: (success?: boolean, finalMessage?: string) => void;
    update: (newMessage: string) => void;
};
/**
 * Creates an animated progress bar that fills up over time
 * @param totalSteps Total number of steps in the progress
 * @param message Message to display alongside the progress bar
 * @param options Configuration options for the animation
 * @returns Object with control methods for updating and completing the progress
 */
export declare function createProgressBar(totalSteps: number, message?: string, options?: {
    width?: number;
    color?: string;
    completeChar?: string;
    incompleteChar?: string;
}): {
    update: (currentStep: number, stepMessage?: string) => void;
    complete: (finalMessage?: string) => void;
};
/**
 * Creates a simple typewriter effect for text
 * @param text Text to display with typewriter effect
 * @param options Configuration options for the animation
 * @returns Promise that resolves when animation is complete
 */
export declare function typewriter(text: string, options?: {
    speed?: number;
    color?: string;
    onComplete?: () => void;
}): Promise<void>;
/**
 * Creates a countdown timer that displays in the terminal
 * @param seconds Total seconds to count down from
 * @param message Message to display alongside the countdown
 * @param options Configuration options for the countdown
 * @returns Object with control methods for the countdown
 */
export declare function createCountdown(seconds: number, message?: string, options?: {
    color?: string;
    onComplete?: () => void;
}): {
    start: () => NodeJS.Timeout;
    stop: () => void;
};
