import { Command } from 'commander';
/**
 * Register the test-error command
 * @param program Commander program instance
 */
export declare function testErrorCmd(program: Command): void;
