import { Command } from 'commander';
/**
 * Register the analytics command
 */
export declare function analyticsCmd(program: Command): void;
export declare const analyticsCommand: typeof analyticsCmd;
