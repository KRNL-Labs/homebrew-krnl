import { Command } from 'commander';
/**
 * Command registration
 */
export declare function setupCommand(program: Command): void;
