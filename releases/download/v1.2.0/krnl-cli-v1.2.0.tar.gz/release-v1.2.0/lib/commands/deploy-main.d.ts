import { Command } from 'commander';
export declare function deployMainCommand(program: Command): void;
