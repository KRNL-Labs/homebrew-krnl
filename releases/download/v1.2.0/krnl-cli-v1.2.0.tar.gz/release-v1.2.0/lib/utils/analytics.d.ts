/**
 * Gets or creates a unique device ID
 */
export declare function getDeviceId(): string;
/**
 * Set analytics enabled/disabled
 */
export declare function setAnalyticsEnabled(enabled: boolean): void;
/**
 * Check if analytics are enabled
 */
export declare function isAnalyticsEnabled(): boolean;
/**
 * Initialize analytics client
 */
export declare function initializeAnalytics(): void;
/**
 * Track an event with PostHog
 */
export declare function trackEvent(eventName: string, properties?: Record<string, any>, userProperties?: Record<string, any>): void;
/**
 * Track a command execution
 */
export declare function trackCommandPosthog(command: string, args?: Record<string, any>, successful?: boolean): void;
/**
 * Capture an exception and send it to PostHog
 * @param error Error to capture
 * @param context Additional context to include
 */
export declare function captureException(error: Error, context?: Record<string, any>): void;
/**
 * Shut down PostHog client
 */
export declare function shutdown(): Promise<void>;
export declare const analytics: {
    trackEvent: typeof trackEvent;
    trackCommandPosthog: typeof trackCommandPosthog;
    setAnalyticsEnabled: typeof setAnalyticsEnabled;
    isAnalyticsEnabled: typeof isAnalyticsEnabled;
    getDeviceId: typeof getDeviceId;
    captureException: typeof captureException;
    shutdown: typeof shutdown;
    initializeAnalytics: typeof initializeAnalytics;
};
export default analytics;
